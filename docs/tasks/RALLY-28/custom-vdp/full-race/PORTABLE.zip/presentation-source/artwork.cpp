
#include "car.hpp"
#include "scenery.hpp"
#include "signs.hpp"
#include "signs_data.hpp"
#include "font_data.hpp"
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <cstdlib>
using namespace rally::game;
constexpr unsigned CarWidth=102,CarHeight=77,Font=63940,LargeFont=63941;
uint8_t carUpload[CarWidth*CarHeight];rally::Stream stream;
void send(const uint8_t *p,unsigned n){if(n&&fwrite(p,1,n,stdout)!=n)std::abort();}
void flush(){send(stream.data,stream.size);stream.size=0;stream.overflow=false;}
void put(unsigned n){putchar(uint8_t(n));}
void word(unsigned n){put(n);put(n>>8);}
void command(unsigned id,unsigned op){put(23);put(0);put(160);word(id);put(op);}
void vdp_adv_clear_buffer(int id){command(id,2);}
void vdp_adv_write_block_data(int id,int n,char *p){command(id,0);word(n);send((uint8_t*)p,n);}
void vdp_select_bitmap(int id){put(23);put(27);put(0);put(id);}
void vdp_adv_bitmap_from_buffer(int w,int h,int format){put(23);put(27);put(33);word(w);word(h);put(format);}
void vdp_set_text_colour(int ink){put(17);put(ink);}
void vdp_set_text_bg_colour(int paper){put(17);put(128+paper);}
void mos_puts(char *p,unsigned n,int){send((uint8_t*)p,n);}
void font(unsigned id) {
    const uint8_t cmd[]={23,0,0x95,0,uint8_t(id),uint8_t(id>>8),0};send(cmd,sizeof(cmd));
}
void fontCreate(unsigned id,unsigned size) {
    const uint8_t cmd[]={23,0,0x95,1,uint8_t(id),uint8_t(id>>8),uint8_t(size),uint8_t(size),uint8_t(size-1),0};
    send(cmd,sizeof(cmd));
}
void loadFont() {
    vdp_adv_clear_buffer(Font);
    vdp_adv_write_block_data(Font,sizeof(FontPixels),(char*)FontPixels);fontCreate(Font,8);
    // A nearest-neighbour 2x derivative uses the identical original glyphs.
    vdp_adv_clear_buffer(LargeFont);
    for(unsigned ch=0;ch<256;++ch) {
        uint8_t doubled[32];
        for(unsigned y=0;y<8;++y) {
            unsigned bits=0;for(unsigned x=0;x<8;++x)bits=(bits<<2)|((FontPixels[ch*8+y]&(128>>x))?3:0);
            doubled[y*4]=doubled[y*4+2]=uint8_t(bits>>8);
            doubled[y*4+1]=doubled[y*4+3]=uint8_t(bits);
        }
        vdp_adv_write_block_data(LargeFont,32,(char*)doubled);
    }
    // Font API requires one contiguous block, even when uploaded in pieces.
    const uint8_t consolidate[]={23,0,0xa0,uint8_t(LargeFont),uint8_t(LargeFont>>8),14};
    send(consolidate,sizeof(consolidate));fontCreate(LargeFont,16);font(Font);
}
void loadScenery() {
    constexpr unsigned Source=63800,Bitmap=100;
    vdp_adv_clear_buffer(Source);
    vdp_adv_write_block_data(Source,sizeof(rally::SceneryPixels),(char*)rally::SceneryPixels);
    vdp_adv_clear_buffer(64000+Bitmap);
    stream.byte(23);stream.byte(0);stream.byte(0xa0);stream.word(64000+Bitmap);
    stream.byte(72);stream.byte(4);stream.word(Source);
    for(auto colour:rally::SceneryPalette)stream.byte(colour);
    flush();vdp_select_bitmap(Bitmap);vdp_adv_bitmap_from_buffer(1024,rally::RoadTop,1);
    vdp_adv_clear_buffer(Source);
}
void loadSigns() {
    constexpr unsigned Source=63800;
    for(unsigned i=0;i<SignCount;++i) {
        const auto &art=SignArtwork[i];const unsigned bitmap=SignBitmapBase+i;
        vdp_adv_clear_buffer(Source);vdp_adv_write_block_data(Source,sizeof(art.pixels),(char*)art.pixels);
        vdp_adv_clear_buffer(64000+bitmap);
        stream.byte(23);stream.byte(0);stream.byte(0xa0);stream.word(64000+bitmap);
        stream.byte(72);stream.byte(4);stream.word(Source);
        for(auto colour:art.palette)stream.byte(colour);
        flush();vdp_select_bitmap(bitmap);vdp_adv_bitmap_from_buffer(64,64,1);
    }
    vdp_adv_clear_buffer(Source);
}
void loadCars() {
    // Upload only the five unmodified player views.
    for(unsigned i=0;i<5;++i) {
        vdp_adv_clear_buffer(64000+i);
        for(unsigned y=0;y<CarHeight;++y)
            for(unsigned x=0;x<CarWidth;++x)
                carUpload[y*CarWidth+x]=
                    rally::CarPixels[i][(y*48/CarHeight)*64+x*64/CarWidth];
        vdp_adv_write_block_data(64000+i,sizeof(carUpload),(char *)carUpload);
        vdp_select_bitmap(i);
        vdp_adv_bitmap_from_buffer(CarWidth,CarHeight,1);
    }
    // Command 72 maps each 8-bit source pixel through a 256-byte table.
    // Always derive from the original view, never a previously recoloured copy.
    constexpr unsigned ColourMapBuffer=63960;
    for(unsigned livery=1;livery<rally::LiveryCount;++livery) {
        for(unsigned pixel=0;pixel<256;++pixel)
            carUpload[pixel]=rally::carColour(pixel,livery);
        vdp_adv_clear_buffer(ColourMapBuffer);
        vdp_adv_write_block_data(ColourMapBuffer,256,(char *)carUpload);
        for(unsigned i=0;i<5;++i) {
            unsigned bitmap=livery*5+i;
            vdp_adv_clear_buffer(64000+bitmap);
            rally::Stream command;
            command.byte(23);command.byte(0);command.byte(0xa0);
            command.word(64000+bitmap);command.byte(72);
            command.byte(0x10); // 8 bits/pixel (0), mapping supplied in buffer.
            command.word(64000+i);command.word(ColourMapBuffer);
            mos_puts((char *)command.data,command.size,0);
            vdp_select_bitmap(bitmap);
            vdp_adv_bitmap_from_buffer(CarWidth,CarHeight,1);
        }
    }
    vdp_adv_clear_buffer(ColourMapBuffer);
    // Matrix feature flag, then x'=-x+101, y'=y. Q0 signed 16-bit inputs.
    // Reflection around the 102-pixel canvas keeps the ground anchor fixed.
    const uint8_t mirrorCommands[]={23,0,0xf8,1,0,1,0,
        23,0,0xa0,0xf0,0xf9,32,0,
        23,0,0xa0,0xf0,0xf9,32,11,0xc0,
        0xff,0xff,0,0,101,0,0,0,1,0,0,0};
    mos_puts((char *)mirrorCommands,sizeof(mirrorCommands),0);

    vdp_set_text_colour(15);
    vdp_set_text_bg_colour(0);

}

int main(int argc,char **argv){if(argc!=2)return 2;
if(!strcmp(argv[1],"artwork")){loadCars();loadSigns();}
else if(!strcmp(argv[1],"presentation")){loadScenery();loadFont();}
else {return 2;}
return ferror(stdout)?1:0;}
