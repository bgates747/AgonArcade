# Preserved complete-race comparison

All17 named cases execute the same real eZ80 racing presentation: panorama
scrolling/repair, moving traffic, signs, player, finish, HUD/footer and engine
commands. The34-run forward/reverse comparison preserves each original native
renderer module and includes transport, backpressure, swaps and ordered frame
completion. RESULTS.md/RESULTS.json own measured whole-race results; historical
flat-background gains are not pooled or presented as complete-race gains.

1. fixtures/ contains all17 exact input sets. source/ contains15 actual source
   packages and target/ contains their authoritative frozen native modules.
   IDENTITIES.json maps split-clear to span-native and static to additive:
   these are input-identical compatibility aliases, not separate optimizations.
   Available authoritative target siblings are preserved from their original
   qualified archives. Missing road ELF/disassembly files are not invented;
   the road archive supplied module images and corresponding helper cores.
2. Inherited rally-render.* build artifacts are omitted from source/ because
   they describe an older compiler delivery. Only target/ holds authoritative
   renderer artifacts. Native source/modules remain unchanged; the real eZ80
   guest is newly compiled from the maintained production presentation and
   admits the module before mode136 and large artwork allocations.
3. guest/, presentation/, production/ and presentation-source/ preserve the
   actual guest, asset loaders, extracted presentation functions, maintained
   source/headers and exact artwork/stream inputs. GUEST-BUILD.json pins them.
   firmware/vdp_rally.bin and runner/ are unchanged qualified prior inputs.
   No new firmware, native compiler or SDK modification is included.
4. captures/ and any coverage diagnostics are separate from throughput. Their
   scene holds deliberately stop after a completed-frame fence; interrupted
   captures do not qualify game cleanup. The full runs and completed coverage
   own timer/StopRace/UNLOAD/clean MOS-return evidence. Raw failures and prior
   preparation archives remain preserved and excluded as reports describe.
5. Every local report/tool/input/raw return is preserved except direct .work
   trees, caches, host .so libraries and symlinks. SHA256SUMS covers every other
   archive member. PACKAGE.json also hashes that file and records CRC/readback
   validation and unchanged selected inputs. Original report/build strings may
   contain historical absolute provenance paths; they are not portable launch
   instructions. Reproduction still needs the pinned repository environment.

COMPARISON-SELECTION.json pins two logical 17-case orders to unchanged original
campaign/case receipts: 29 successful runs before the external boost interruption
and five finishing runs under a new guard. The interrupted run is excluded.
RESULTS.json lists all 34 source references. There are no synthetic campaign
copies. Only executable-identical baseline/native/additive replicas are pooled;
the observed repeat range limits interpretation of small wider-fill differences.
The accepted additive sampler with byte fills remains the reference.

Author moving visual review remains pending. Hardware has not been tested, and
packaging does not promote a candidate, authorize another emulator run, physical
deployment or publication.
