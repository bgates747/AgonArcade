# Qualified sprite comparison inputs and targets

The completed comparison uses fixtures/clipfix-affine and
fixtures/clipfix-additive. Their embedded modules are identical to
target/control/rally-render.vdpl and target/candidate/rally-render.vdpl,
respectively. The candidate module SHA256 is
310779643769adde8413b93ea282115990dfebfe873e3395ac5545ac9d506702.

Use the artifacts under target/ for the qualified compiler outputs, ELF files,
disassembly, stack reports and module manifests. Files named rally-render.*
under source/control/ or source/candidate/ were inherited from an earlier
compiler-delivery package and are preserved as provenance. In particular, their
48eac7... .vdpl/ELF artifacts are not the compiled span/sprite candidates.
The source/helper files alongside them describe the later renderer changes;
the qualified builds are explicitly separated under target/ to remove ambiguity.

firmware/vdp_rally.bin is the unchanged firmware used for these fixtures.
Compilation tooling/runtime dependencies remain pinned in the repository;
this archive does not replace that build environment. Hardware deployment and
human visual acceptance are separate from preserving these exact bytes.

SHA256SUMS covers every other member. The external PACKAGE.json also hashes
SHA256SUMS and records archive/readback validation. Earlier registered variants
and diagnostic builds are preserved separately in DIAGNOSTICS.zip. Raw emulator
evidence remains in the repository evidence/ directories and is not repackaged.
