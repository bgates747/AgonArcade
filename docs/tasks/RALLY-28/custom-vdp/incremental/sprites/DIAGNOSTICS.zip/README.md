# Registered variant and diagnostic preservation

This archive preserves every FIXTURES.json case outside the final clipfix pair,
including registered diagnostics that were never run. Registration and archive
validation are not assertions that a target run passed. Consult the repository's
RESULTS.md, campaign receipts and unchanged raw evidence for each actual outcome.
Some preserved additive variants contain the superseded clipping behavior, and
some larger diagnostic modules failed LOAD on the pinned runtime. Those inputs
are retained deliberately and must not be promoted to the final candidate.

fixtures/ contains the exact registered input files. diagnostics/ contains each
instrumented package, its actual target outputs, BUILD.json and independently
qualified HOST-EXPECTED.json. Host fake-clock qualification establishes state,
format and protocol checks; it supplies no target timing evidence.

preclip/package and preclip/target retain the earlier uncorrected sprite
candidate. The package directories also contain inherited rally-render.* files
from the earlier 48eac7... delivery. Those inherited binaries are provenance;
the corresponding target/ directory contains the actual module and compiler
artifacts for that diagnostic or earlier candidate. The final corrected target
31077964... is under target/candidate/ in PORTABLE.zip, not in preclip/.

registry/FIXTURES.json is an exact registry snapshot. CASES.json labels these as
registered inputs with no run-pass claim. SHA256SUMS covers every other member;
the external DIAGNOSTICS.json also hashes SHA256SUMS and records validation.
Raw emulator logs/screenshots/receipts remain outside this archive, unchanged.
Host .so libraries and Python/cache files are excluded.
