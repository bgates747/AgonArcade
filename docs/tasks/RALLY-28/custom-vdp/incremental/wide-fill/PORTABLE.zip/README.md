# Preserved wider road-fill experiment

This archive preserves the byte-fill control and the aligned-word candidate,
their exact moving fixtures, the separate isolated fill probe, host qualification
and raw returned evidence. The whole-frame comparison did not establish a gain;
the candidate is preserved for evidence and was not promoted to the control.
Consult RESULTS.json and the experiment documents for the measured variation.

1. source/control and source/candidate contain the actual application packages.
   Inherited rally-render.* compiler-delivery artifacts are omitted from those
   directories. Only target/control and target/candidate contain the authoritative
   full-fixture module, ELF, object, disassembly, stack and compiler metadata.
2. fixtures/byte and fixtures/word are the exact completed-frame input sets.
   phase/ preserves the separately qualified source, target, fixture, inputs,
   host format checks and raw emulator counter returns. Host fake-clock output
   and isolated raw emulated CCOUNT are distinct from completed-frame timing.
3. Local test/build/runner tools, reports and original metadata are retained.
   EXPERIMENT-README.md is the repository's experiment overview. The selected
   shared runner is under runner/; qualification/fill-units retains the extracted
   original primitive and raw unit-test process output. Host .so libraries,
   caches, direct .work trees and inherited source-package build outputs are
   omitted. No archive member is a symlink.
4. firmware/vdp_rally.bin is extracted unchanged from the accepted sprite
   archive. IDENTITY.json supplies portable relative paths and identities.
   Exact original reports can contain historical absolute provenance strings;
   those strings are not portable path instructions. Rebuilding and launching
   still require the pinned repository toolchain, SDK and emulator environment.
5. evidence/ and phase/evidence/ retain raw returned files without editing them.
   SHA256SUMS covers every other archive member. The external PACKAGE.json also
   hashes SHA256SUMS and records CRC/readback validation. Preservation does not
   authorize another emulator run, hardware deployment or publication.
