# Preserved two-page static-drawing experiment

This archive contains the accepted additive-sampler/byte-fill control and a
tape-only candidate that initializes static title/sky/lower-strip pixels on both
display pages, then restores only the sky rows that moving actors can touch.
The native module, original full-size artwork, generated physics, motion table,
driver, resource allocations, firmware, frame swaps and completion fences are
unchanged. Consult RESULTS.md/RESULTS.json for measured whole-frame results.

1. fixtures/control and fixtures/static are the exact900-frame benchmark input
   sets. Both embed the same authoritative target/control/rally-render.vdpl.
   source/control is the corresponding accepted source package. Inherited old
   rally-render.* delivery artifacts are omitted from source/control; only
   target/control contains the actual accepted module/ELF/object/disassembly/
   stack and compiler metadata. No new native compilation was performed.
2. captures/ contains separate30/31-frame scene-hold diagnostics and raw returns.
   Their hold and deliberate interruption are excluded from benchmark timing.
   A successful capture does not qualify game cleanup; the completed900-frame
   benchmark runs own final-state/timer/StopRace/UNLOAD/MOS-return evidence.
3. All local experiment tools, reports, fixture registries, scene diagnostics and
   raw returned evidence are preserved recursively. EXPERIMENT-README.md is the
   repository overview. Direct .work trees, caches, host .so libraries and
   symlinks are excluded. runner/ retains the selected pinned shared runner and
   the exact reused motion-control runner. No new emulator is included.
4. The shared source, authoritative target and firmware/vdp_rally.bin are copied
   unchanged from the verified prior wider-fill archive's CONTROL, never its
   rejected wider-fill candidate. IDENTITY.json gives portable relative paths.
   Exact original reports may contain historical absolute provenance strings;
   those are evidence, not portable path instructions. Rebuilding/running tools
   still requires the pinned repository toolchain, SDK and emulator environment.
5. SHA256SUMS hashes every other member. External PACKAGE.json also hashes that
   file and records CRC/readback checks and selected-input preservation.

The candidate is preserved for Author visual review and is not adopted by this
archive. Hardware has not been tested. Preservation does not authorize another
emulator run, physical deployment or publication.
